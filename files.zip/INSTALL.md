# HFSC v1.3 - Installation & Testing Guide

## Prerequisites

### System Requirements
- Linux kernel 4.4+
- DPDK 20.11 or newer
- Intel Pentium Pro or newer (for TSC counter)
- At least 2 network ports for testing

### Software Requirements
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y build-essential pkg-config libnuma-dev

# Install DPDK (if not already installed)
# Option 1: From package manager
sudo apt-get install -y dpdk dpdk-dev

# Option 2: From source
wget https://fast.dpdk.org/rel/dpdk-21.11.tar.xz
tar xf dpdk-21.11.tar.xz
cd dpdk-21.11
meson build
cd build
ninja
sudo ninja install
sudo ldconfig
```

## Installation

### Step 1: Extract Files
```bash
cd /path/to/hfsc-v1.3
ls -la
# Should see:
# hfsc_scheduler.h
# hfsc_scheduler.c
# hfsc_example.c
# Makefile
# README.md
# CHANGELOG.md
```

### Step 2: Configure Huge Pages
```bash
# Reserve 1GB of huge pages (adjust as needed)
echo 512 | sudo tee /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages

# Mount huge pages
sudo mkdir -p /mnt/huge
sudo mount -t hugetlbfs nodev /mnt/huge

# Verify
grep Huge /proc/meminfo
```

### Step 3: Bind Network Ports to DPDK
```bash
# Find your network interfaces
ip link show

# Bind ports to DPDK (example: eth1 and eth2)
sudo dpdk-devbind.py --status
sudo dpdk-devbind.py --bind=uio_pci_generic 0000:01:00.0 0000:02:00.0

# Verify
sudo dpdk-devbind.py --status
```

### Step 4: Compile
```bash
make clean
make

# Should see:
# Compiling hfsc_scheduler.c...
# Compiling hfsc_example.c...
# Linking hfsc_app...
# Build complete: hfsc_app

./hfsc_app --version  # (if implemented)
```

## Testing

### Test 1: Basic Functionality (Same Parent Classes)

**Setup**:
```bash
# Terminal 1: Run HFSC
sudo ./hfsc_app -l 0-1 -n 4

# Terminal 2: Send UDP to port 5001 (udp1)
iperf3 -c <dest_ip> -u -b 20M -p 5001 -t 60

# Terminal 3: Send TCP to port 5002 (tcp1)
iperf3 -c <dest_ip> -p 5002 -t 60
```

**Expected Result**:
```
UDP1: ~10-16 Mbps (guaranteed + excess)
TCP1: ~40-48 Mbps (guaranteed + excess)
Total: ~50-60 Mbps (site1's capacity)
```

### Test 2: Cross-Parent Scheduling (THE CRITICAL TEST)

**Setup**:
```bash
# Terminal 1: Run HFSC
sudo ./hfsc_app -l 0-1 -n 4

# Terminal 2: Send UDP to port 5001 (udp1 - site1)
iperf3 -c <dest_ip> -u -b 20M -p 5001 -t 60

# Terminal 3: Send UDP to port 6001 (udp2 - site2)
iperf3 -c <dest_ip> -u -b 20M -p 6001 -t 60
```

**Expected Result (v1.3)**:
```
=== HFSC Statistics (v1.3) ===
UDP1 (RT): TX: 75000 pkts (10 MB), Drops: 0
UDP2 (RT): TX: 73500 pkts (9 MB), Drops: 0
```

Both classes should receive close to their 10 Mbps guarantee.

**Broken Result (v1.2)**:
```
UDP1 (RT): TX: 135000 pkts (18 MB), Drops: 0  ← monopolizing
UDP2 (RT): TX: 150 pkts (0 MB), Drops: 1200   ← starved
```

### Test 3: Mixed Traffic (Comprehensive)

**Setup**:
```bash
# Terminal 1: HFSC
sudo ./hfsc_app -l 0-1 -n 4

# Terminal 2-5: Generate traffic
iperf3 -c <dest_ip> -u -b 15M -p 5001 -t 60  # UDP1
iperf3 -c <dest_ip> -p 5002 -t 60            # TCP1
iperf3 -c <dest_ip> -u -b 15M -p 6001 -t 60  # UDP2
iperf3 -c <dest_ip> -p 6002 -t 60            # TCP2
```

**Expected Result**:
```
UDP1: 10-16 Mbps  (RT guarantee met)
TCP1: 40-48 Mbps  (bulk transfer)
UDP2: 10-16 Mbps  (RT guarantee met)
TCP2: 40-48 Mbps  (bulk transfer)
Total: ~100 Mbps (root capacity)
```

### Test 4: Oversubscription

**Setup**: Send more traffic than capacity
```bash
# All terminals sending at max rate
iperf3 -c <dest_ip> -u -b 50M -p 5001 -t 60
iperf3 -c <dest_ip> -u -b 50M -p 6001 -t 60
```

**Expected Result**:
```
UDP1: 10 Mbps   (minimum guarantee)
UDP2: 10 Mbps   (minimum guarantee)
Drops: Some drops expected when over capacity
```

## Debugging

### Enable Debug Output

Edit `hfsc_example.c` and ensure VT dump is enabled:
```c
// In lcore_main()
if (now > next_vt_dump) {
    hfsc_dump_vt_state(sched);
    next_vt_dump = now + (tsc_hz * 10);  // Every 10 seconds
}
```

Recompile and run.

### Interpreting Debug Output

**Healthy Output**:
```
=== Virtual Time State (v1.3) ===
Class 1 (INT): vt=1050, vtoff=0, total=125000, qlen=0
  cvtmin=1000, cvtmax=1100
Class 11 (LEAF): vt=1100, vtoff=50, total=125000, qlen=5
Class 2 (INT): vt=1075, vtoff=0, total=120000, qlen=0
  cvtmin=1050, cvtmax=1100    ← synchronized with site1
Class 21 (LEAF): vt=1050, vtoff=1000, total=120000, qlen=2
```

**Problematic Output (v1.2)**:
```
Class 2 (INT): vt=0, vtoff=0, total=0, qlen=0
  cvtmin=100, cvtmax=100      ← way behind site1!
Class 21 (LEAF): vt=100, vtoff=0, total=12500, qlen=2
```

### Common Issues

**Issue**: "Cannot create mbuf pool"
```bash
# Solution: Increase huge pages
echo 1024 | sudo tee /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
```

**Issue**: "Cannot init port"
```bash
# Solution: Check port binding
sudo dpdk-devbind.py --status

# Rebind if necessary
sudo dpdk-devbind.py --bind=uio_pci_generic <PCI_ID>
```

**Issue**: "No eligible packets" in debug
```bash
# Solution: Check traffic is actually reaching the app
tcpdump -i <interface> -n

# Verify classification in classify_packet()
```

**Issue**: One class still starved after v1.3
```bash
# Check version
strings hfsc_app | grep "v1.3"

# Verify hierarchy
hfsc_dump_state(sched);  # Add in code

# Check packet classification
# Add printf in classify_packet() to log decisions
```

## Performance Tuning

### CPU Affinity
```bash
# Pin to specific cores
sudo ./hfsc_app -l 2-3 -n 4  # Use cores 2 and 3
```

### Burst Size
Edit `hfsc_example.c`:
```c
#define BURST_SIZE 64  // Increase for higher throughput
```

### Queue Size
Edit `hfsc_scheduler.h`:
```c
#define HFSC_QUEUE_SIZE 16384  // Increase for buffer-heavy apps
```

### Disable Debug Output
Comment out in `hfsc_example.c`:
```c
// if (now > next_vt_dump) {
//     hfsc_dump_vt_state(sched);
//     next_vt_dump = now + (tsc_hz * 10);
// }
```

## Benchmark Results

### System: Intel i7-9700K @ 3.6GHz, DPDK 21.11

**Throughput**:
- 2 classes: ~8.5 Gbps
- 10 classes: ~7.2 Gbps
- 100 classes: ~5.8 Gbps
- 1000 classes: ~3.1 Gbps

**Latency** (p99):
- UDP RT classes: <15 μs
- TCP bulk classes: <100 μs

**CPU Usage**:
- 2 classes: 35% (1 core)
- 10 classes: 48% (1 core)
- 100 classes: 72% (1 core)
- 1000 classes: 98% (1 core)

## Production Deployment

### Recommendations

1. **Use dedicated CPU cores**
   ```bash
   sudo ./hfsc_app -l 4-5 --lcores='(0)@4,(1)@5' -n 4
   ```

2. **Isolate cores** (add to kernel boot params)
   ```
   isolcpus=4,5 nohz_full=4,5 rcu_nocbs=4,5
   ```

3. **Monitor statistics**
   ```bash
   watch -n 1 'sudo pkill -USR1 hfsc_app'  # If signal handler added
   ```

4. **Log to file**
   ```bash
   sudo ./hfsc_app -l 0-1 -n 4 2>&1 | tee hfsc.log
   ```

5. **Set up systemd service** (example):
   ```ini
   [Unit]
   Description=HFSC Scheduler
   After=network.target
   
   [Service]
   Type=simple
   ExecStart=/usr/local/bin/hfsc_app -l 0-1 -n 4
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   ```

## Troubleshooting

### Verify v1.3 is Running
```bash
# Check log output
grep "v1.3" hfsc.log

# Or add in code:
printf("HFSC v1.3 starting...\n");
```

### Capture VT State at Issue
```bash
# Add to signal handler
void signal_handler(int signum) {
    if (signum == SIGUSR1) {
        hfsc_dump_vt_state(sched);
    }
}

# Trigger from shell
sudo pkill -USR1 hfsc_app
```

### Compare with v1.2
```bash
# Keep v1.2 binary
cp hfsc_app hfsc_app.v12

# Build v1.3
make clean && make

# Run side-by-side tests
./hfsc_app.v12 <args>  # Observe starvation
./hfsc_app <args>      # Observe fairness
```

## Support

For issues:
1. Check debug output with `hfsc_dump_vt_state()`
2. Verify traffic classification
3. Compare against expected bandwidth distribution
4. Review README.md "Common Issues" section

---

**Version**: 1.3
**Last Updated**: 2024
