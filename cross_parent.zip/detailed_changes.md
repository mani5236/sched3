# Detailed Changes in v1.4

## 1. NEW FUNCTION: hfsc_get_max_vt_at_level()

**Location:** Around line 260 (before hfsc_activate_class)

**Purpose:** Get the maximum virtual time across all active siblings at the same hierarchy level

```c
/* CRITICAL FIX v1.4: Get maximum VT across all active branches at same level */
static uint64_t hfsc_get_max_vt_at_level(hfsc_class_t *parent)
{
    uint64_t max_vt = 0;
    
    if (parent == NULL) return 0;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *sibling = parent->children[i];
        if (sibling->state == HFSC_CLASS_ACTIVE) {
            /* Check both the sibling's own VT and its children's VT range */
            if (sibling->cl_vt > max_vt) {
                max_vt = sibling->cl_vt;
            }
            if (sibling->cl_cvtmax > max_vt) {
                max_vt = sibling->cl_cvtmax;
            }
        }
    }
    
    return max_vt;
}
```

**What it does:**
- Takes a parent node
- Iterates through all its children (siblings)
- Finds the maximum VT among active siblings
- Also checks cl_cvtmax (max VT of their children) to get the true maximum

---

## 2. MODIFIED: hfsc_activate_class() - FSC Section

**Location:** Around line 280-320

**OLD CODE (v1.3):**
```c
if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
    if (cl->parent && cl->parent->state == HFSC_CLASS_ACTIVE) {
        if (cl->cl_parentperiod != cl->parent->cl_vtperiod) {
            cl->cl_parentperiod = cl->parent->cl_vtperiod;
            
            uint64_t parent_vt;
            
            if (cl->parent->cl_cvtmin != UINT64_MAX && cl->parent->cl_cvtmax != 0) {
                /* Use average instead of minimum */
                parent_vt = (cl->parent->cl_cvtmin + cl->parent->cl_cvtmax) / 2;
            } else {
                parent_vt = cl->parent->cl_vt;
            }
            
            if (parent_vt > cl->cl_vt) {
                cl->cl_vtoff = parent_vt - cl->cl_vt;
            } else {
                cl->cl_vtoff = 0;
            }
        }
    } else if (cl->parent) {
        cl->cl_parentperiod = cl->parent->cl_vtperiod;
        if (cl->parent->cl_vt > cl->cl_vt) {
            cl->cl_vtoff = cl->parent->cl_vt - cl->cl_vt;
        } else {
            cl->cl_vtoff = 0;
        }
    }
    
    hfsc_update_sc(&cl->cl_fsc, &cl->fsc, cur_time, cl->total, sched->tsc_hz);
    cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
    cl->cl_vt += cl->cl_vtoff;
}
```

**NEW CODE (v1.4):**
```c
if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
    /* Update FSC based on current service */
    hfsc_update_sc(&cl->cl_fsc, &cl->fsc, cur_time, cl->total, sched->tsc_hz);
    cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
    
    if (cl->parent && cl->parent->state == HFSC_CLASS_ACTIVE) {
        /* CRITICAL FIX v1.4: Sync with maximum VT across all active siblings */
        uint64_t max_sibling_vt = hfsc_get_max_vt_at_level(cl->parent);
        
        /* If this class is behind, adjust its VT offset */
        if (cl->cl_parentperiod != cl->parent->cl_vtperiod) {
            cl->cl_parentperiod = cl->parent->cl_vtperiod;
            
            if (max_sibling_vt > cl->cl_vt) {
                cl->cl_vtoff = max_sibling_vt - cl->cl_vt;
            } else {
                cl->cl_vtoff = 0;
            }
        }
    } else if (cl->parent) {
        /* Parent is inactive - check if siblings exist at parent level */
        cl->cl_parentperiod = cl->parent->cl_vtperiod;
        
        /* CRITICAL FIX v1.4: Even if parent is inactive, sync with active cousins */
        if (cl->parent->parent) {
            uint64_t max_cousin_vt = hfsc_get_max_vt_at_level(cl->parent->parent);
            if (max_cousin_vt > cl->cl_vt) {
                cl->cl_vtoff = max_cousin_vt - cl->cl_vt;
            } else {
                cl->cl_vtoff = 0;
            }
        }
    }
    
    /* Apply offset */
    cl->cl_vt += cl->cl_vtoff;
}
```

**Key Changes:**
1. **Moved hfsc_update_sc() and initial VT calculation to the TOP** - compute VT first
2. **When parent is ACTIVE**: Use `hfsc_get_max_vt_at_level(cl->parent)` instead of parent's cvtmin/cvtmax average
3. **When parent is INACTIVE (else if branch)**: NEW logic added:
   - Check if grandparent exists (`cl->parent->parent`)
   - Call `hfsc_get_max_vt_at_level(cl->parent->parent)` to get max VT from "cousins"
   - This is the CRITICAL fix for cross-branch synchronization

---

## 3. MODIFIED: hfsc_deactivate_class() - Small Addition

**Location:** Around line 380

**Added at the end:**
```c
if (!has_active_child) {
    /* Reset VT tracking when last child deactivates */
    cl->parent->cl_cvtmin = UINT64_MAX;
    cl->parent->cl_cvtmax = 0;
    
    hfsc_deactivate_class(sched, cl->parent);
} else {
    /* CRITICAL FIX v1.4: Update parent VT even if still active */
    if (cl->parent->fsc.m1 == 0 && cl->parent->fsc.m2 == 0) {
        if (cl->parent->cl_cvtmin != UINT64_MAX && cl->parent->cl_cvtmax != 0) {
            cl->parent->cl_vt = (cl->parent->cl_cvtmin + cl->parent->cl_cvtmax) / 2;
        }
    }
}
```

**What changed:**
- Added an `else` clause when parent still has active children
- Updates interior node's VT based on remaining children's VT range

---

## 4. VERSION UPDATES

Changed version strings from "v1.3" to "v1.4" in:
- hfsc_init() log message
- hfsc_dump_state() 
- hfsc_dump_vt_state()

---

## Summary of Changes

**3 main modifications:**

1. **NEW FUNCTION**: `hfsc_get_max_vt_at_level()` - finds maximum VT across siblings
2. **MAJOR CHANGE**: `hfsc_activate_class()` - uses new function to sync VT across branches
3. **MINOR CHANGE**: `hfsc_deactivate_class()` - updates parent VT when children remain active

**The critical fix** is in #2, specifically the new `else if (cl->parent)` branch that syncs with cousins when the parent is inactive.
